import streamlit as st

# --- Replace these with your real implementations from the notebook ---
def extract_metric(firm: str, period: str, metric: str):
    # TODO: wire up to your pandas logic from notebooks/BCG_GENAI.ipynb
    # Return a dict like: {"value": 0.23, "unit": "%", "source": "10-Q 2025Q2"}
    mock = {
        "revenue_growth": {"value": 12.4, "unit": "%", "source": "10-Q 2025Q2"},
        "operating_margin": {"value": 18.1, "unit": "%", "source": "10-K 2024"},
        "debt_ratio": {"value": 0.42, "unit": "", "source": "10-K 2024"}
    }
    return mock.get(metric, {"value": None, "unit": "", "source": "unknown"})

def route_intent(text: str):
    t = text.lower()
    if "revenue" in t: return {"intent": "metric", "metric": "revenue_growth"}
    if "margin" in t:  return {"intent": "metric", "metric": "operating_margin"}
    if "debt" in t:    return {"intent": "metric", "metric": "debt_ratio"}
    return {"intent": "fallback"}

def answer(query: str, firm: str, period: str):
    intent = route_intent(query)
    if intent["intent"] == "metric":
        m = extract_metric(firm, period, intent["metric"])
        if m["value"] is None:
            return "Metric not found. Try: revenue, margin, or debt."
        return f"{intent['metric'].replace('_',' ').title()} for {firm} {period}: {m['value']}{m['unit']} (source: {m['source']})"
    return "I didn't recognize the request. Try: 'What is revenue growth?'"

# --- Streamlit UI ---
st.title("Financial Filings Insights (Prototype)")
st.caption("BCG GenAI Job Simulation — backend logic demo")

with st.sidebar:
    st.header("Context")
    firm = st.text_input("Firm", "ACME Corp")
    period = st.text_input("Period", "2025Q2")

st.subheader("Ask a question")
q = st.text_input("e.g., What is operating margin?")

if st.button("Ask"):
    st.write(answer(q, firm, period))

st.divider()
st.subheader("Examples")
st.write("- What is revenue growth?")
st.write("- What is operating margin?")
st.write("- What is the debt ratio?")
